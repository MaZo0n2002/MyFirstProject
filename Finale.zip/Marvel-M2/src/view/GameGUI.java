package view;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import engine.Game;
import engine.Player;
import engine.PriorityQueue;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;

public class GameGUI extends JFrame implements ActionListener{
     
	private Game game;
	private JButton start;
	private JPanel begin;
	private JPanel name;
	private JLabel first;
	private JLabel second;
	private JFrame frame;
	private JFrame DisChamp;
	private JFrame FirstLeader;
	private JTextField Fname;
	private JTextField Sname;
	private JButton New;
	private JPanel Champ;
	private ArrayList <JButton> Buttons = new ArrayList<JButton>();
	private JFrame Board ;
	private JPanel DisBoard;
	private JLabel FirstTeam;
	private JLabel SecondTeam;
	private JTextArea Fteam;
	private JTextArea Steam;
	private JPanel Team;
	private int count = 0;
	private Player firstPlayer;
	private Player secondPlayer;
	private String s;
	private JButton submit;
	private JPanel Fleader;
	private JButton FChoose;
	private JPanel Sleader;
	private JButton FPleader;
	private JButton SPleader;
	private ArrayList <JButton> team1 = new ArrayList<JButton>();
	private ArrayList <JButton> team2 = new ArrayList<JButton>();
	private JPanel right ;
	private JPanel left ;
	private JPanel up ;
	private JPanel down ;
	private JLabel FIRSTPLAYERTEAM;
	private JButton moveUP;
	private JButton moveDOWN;
	private JButton moveRIGHT;
	private JButton moveLEFT;
	private JButton attackUP;
	private JButton attackDOWN;
	private JButton attackLEFT;
	private JButton attackRIGHT;
	private JButton UseLeaderAbility;
	private ArrayList <Champion> temp = new ArrayList <Champion>();
	private JButton EndTurn ;
	private JButton z1;
	private JButton CastAbility;
	private JButton Cast1;
	private JButton Cast2;
	private JButton Cast3;
	private JFrame ability;
	private JButton punch ;

	private String S;
	private JTextArea Curr;
	private JLabel details;
	
public GameGUI() {

	setLayout(new BorderLayout());
	begin = new JPanel ();
    add(begin , BorderLayout.CENTER);
	setTitle("Welcome to Marvel");
	ImageIcon image=new ImageIcon("Marvel1.jpg");
	setContentPane(new JLabel(image));
	
	start = new JButton("Welcome to Marvel World");
	start.setBounds(350,450,300,40);
	start.setFocusable(false);
	start.setPreferredSize(new Dimension(200,50));
	start.addActionListener(this);
	add(start, BorderLayout.CENTER);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setSize(1000,600);
	setResizable(true);
	setBackground(new Color(0,1,1));
    setVisible(true);
	begin.repaint();
	begin.revalidate();
	repaint();
	revalidate();
	
    name = new JPanel();
    name.setLayout(new GridLayout(0,1));
    name.setBackground(new Color (0x123456));
    
    first = new JLabel("First Player Name:");
    first.setFont(new Font("Serif", Font.PLAIN, 30));
    first.setForeground(Color.WHITE);
    first.setBounds(400, 360, 200,20);
    name.add(first);
    Fname = new JTextField();
    name.add(Fname);
    
    second = new JLabel("Second Player Name:");
    second.setFont(new Font("Serif", Font.PLAIN, 30));
    second.setForeground(Color.WHITE);
    second.setBounds(400, 380 , 200,60);
    name.add(second);
    Sname = new JTextField();
    name.add(Sname);
    
    New = new JButton("Play");
    New.setFont(new Font("serif", Font.PLAIN, 20));
    New.addActionListener(this);
    name.add(New);
    
    name.repaint();
    name.revalidate();
    
    Champ = new JPanel ();
    Champ.setLayout(new GridLayout(0,5));
    Champ.setVisible(true);
    Champ.repaint();
    Champ.revalidate();
    submit = new JButton("Choose");
    submit.addActionListener(this);

    Team = new JPanel ();
    Team.setLayout(new GridLayout(2,0));
    Team.repaint(); Team.revalidate();
    
    Fleader = new JPanel();
    Fleader.setLayout(new GridLayout(3,1));
    Fleader.setPreferredSize(new Dimension (500,600));
    Fleader.repaint(); Fleader.revalidate();
    Sleader = new JPanel();
    Sleader.setLayout(new GridLayout(3,1));
    Sleader.setPreferredSize(new Dimension (500,600));
    FChoose = new JButton("Submit");
    FChoose.addActionListener(this);
    Sleader.repaint(); Sleader.revalidate();    Fleader.repaint(); Fleader.revalidate();
    DisBoard = new JPanel();
    DisBoard.setLayout(new GridLayout(5,5));

    DisBoard.setVisible(true);
    DisBoard.repaint(); DisBoard.revalidate();
    right = new JPanel();
    right.setVisible(true);
    right.setPreferredSize(new Dimension(300 , 500)); 
    right.repaint(); right.revalidate();
    left= new JPanel();
    left.setVisible(true);
    left.setPreferredSize(new Dimension(100, 300)); 
    left.setLayout(new FlowLayout());
    left.repaint(); left.revalidate();
   
    
    up  = new JPanel();
    
    for (int i = 0 ; i < temp.size() ; i++) {
    	JButton c = new JButton(temp.get(i).getName());
    	JLabel turn = new JLabel();
    	turn.setPreferredSize(getMaximumSize());
    	turn.add(c);
    	up.add(turn);
    	up.revalidate();  up.repaint();
    }
    
    up.setVisible(true);
    up.setPreferredSize(new Dimension(100 , 100));    up.repaint(); up.revalidate();
    down = new JPanel();
    down.setPreferredSize(new Dimension(100 , 100));   down.repaint();  down.revalidate();
    FIRSTPLAYERTEAM = new JLabel();
    FIRSTPLAYERTEAM.setVisible(true);
    
    moveUP = new JButton("move up");
    moveUP.addActionListener(this);
    moveUP.setPreferredSize(new Dimension(150,30));
    moveDOWN = new JButton("move down");
    moveDOWN.addActionListener(this);
    moveDOWN.setPreferredSize(new Dimension(150,30));
    moveRIGHT = new JButton("move right");
    moveRIGHT.addActionListener(this);
    moveRIGHT.setPreferredSize(new Dimension(150,30));
   
    moveLEFT = new JButton("move left");
    moveLEFT.addActionListener(this);
    moveLEFT.setPreferredSize(new Dimension(150,30));
    attackUP = new JButton("attack up");
    attackUP.addActionListener(this);
    attackUP.setPreferredSize(new Dimension(150,30));
    UseLeaderAbility = new JButton ("Use Leader Ability");
    UseLeaderAbility.setPreferredSize(new Dimension(150,30));
    UseLeaderAbility.addActionListener(this);
    
    attackDOWN = new JButton ("attack down");
    attackDOWN.addActionListener(this);
    attackDOWN.setPreferredSize(new Dimension(150,30));
    attackRIGHT = new JButton ("attack right");
    attackRIGHT.addActionListener(this);
    attackRIGHT.setPreferredSize(new Dimension(150,30));
    attackLEFT = new JButton ("attack left");
    attackLEFT.addActionListener(this);
    attackLEFT.setPreferredSize(new Dimension(150,30));
    
  
    Cast1 = new JButton ();
    Cast1.addActionListener(this);
    Cast2 = new JButton();
    Cast2.addActionListener(this);
    Cast3 = new JButton ();
    Cast3.addActionListener(this);
    
    punch = new JButton();
    punch.addActionListener(this);
       
    
    EndTurn = new JButton ("End Turn");
    EndTurn.addActionListener(this);
    EndTurn.setPreferredSize(new Dimension(150,30));
    
    
    Curr= new JTextArea(s);
	details= new JLabel();
	Curr.repaint(); Curr.revalidate();
	right.add(Curr);

}
	
	@Override
	public void actionPerformed(ActionEvent e) {
	
		if (e.getSource() == start){
			dispose();
		frame = new JFrame();
		frame.setLayout(new BorderLayout());
		frame.add(name , BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1000,600);
		frame.setVisible(true);
		frame.setResizable(true);
		frame.revalidate();  frame.repaint();
		firstPlayer = new Player (Fname.getText());
		secondPlayer = new Player(Sname.getText());
	
		
		game = new Game(firstPlayer , secondPlayer); 
		 JLabel x= new JLabel ("Current Champion details");
		try {
			game.loadAbilities("Abilities.csv");
			game.loadChampions("Champions.csv");
			  for (Champion c : Game.getAvailableChampions()) {
					JButton champion = new JButton();
					champion.setText(c.getName());
				  s = "<html>" +"Name: "+ c.getName() + "<br>";
				  s+= "MaxHp: " + c.getMaxHP() +"<br>";
				  s+= "Attack Damage: " + c.getAttackDamage() +"<br>";
				  s+= "Attack Range: " + c.getAttackRange() + "<br>";
				  s+= "Speed: " + c.getSpeed() + "<br>";
				  s+= "Max Action Points: " + c.getMaxActionPointsPerTurn()+ "<br>";
				  s+= "Ability 1: "+ c.getAbilities().get(0).getName()+ "<br>" +"Area of Effect: " +c.getAbilities().get(0).getCastArea()+"<br>" +
						  "Cast Range: "+c.getAbilities().get(0).getCastRange()+"<br>"+"Base Cooldown: " +c.getAbilities().get(0).getBaseCooldown() +
						  "<br>"+ "Current Cooldown: "+c.getAbilities().get(0).getCurrentCooldown()+"<br>"+ "Cast Range: "+c.getAbilities().get(0).getCastRange()+ 
						 "<br>"+ "Mana Cost: "+c.getAbilities().get(0).getManaCost() +"<br>"+ "Action Cost: "+ c.getAbilities().get(0).getRequiredActionPoints()+
						 "<br>";//heal amount or damage amount;
				  s+="Ability 2: " + c.getAbilities().get(1).getName() +"<br>"+"Area of Effect: " +c.getAbilities().get(1).getCastArea()+"<br>" +
						  "Cast Range: "+c.getAbilities().get(1).getCastRange()+"<br>"+"Base Cooldown: " +c.getAbilities().get(1).getBaseCooldown() +
						  "<br>"+ "Current Cooldown: "+c.getAbilities().get(1).getCurrentCooldown()+"<br>"+ "Cast Range: "+c.getAbilities().get(1).getCastRange()+ 
						 "<br>"+ "Mana Cost: "+c.getAbilities().get(1).getManaCost() +"<br>"+ "Action Cost: "+ c.getAbilities().get(1).getRequiredActionPoints()+
						 "<br>";//heal amount or damage amount;
				 s+="Ability 3: "+ c.getAbilities().get(2).getName() +"<br>"+"Area of Effect: " +c.getAbilities().get(2).getCastArea()+"<br>" +
						  "Cast Range: "+c.getAbilities().get(2).getCastRange()+"<br>"+"Base Cooldown: " +c.getAbilities().get(2).getBaseCooldown() +
						  "<br>"+ "Current Cooldown: "+c.getAbilities().get(2).getCurrentCooldown()+"<br>"+ "Cast Range: "+c.getAbilities().get(2).getCastRange()+ 
						 "<br>"+ "Mana Cost: "+ c.getAbilities().get(2).getManaCost() +"<br>"+ "Action Cost: "+ c.getAbilities().get(2).getRequiredActionPoints()+
						 "<html>" ;//heal amount or damage amount;
//					for (int i = 0 ; i < c.getAppliedEffects().size() ; i++) {
//						s+= "Applied Effects Name: " + c.getAppliedEffects().get(i).getName() +"<br>" + "Applied Effects Duration: "+c.getAppliedEffects().get(i).getDuration() + "<html>";
//					}
				 
						String image = c.getName()+".png";
						ImageIcon img = new ImageIcon (image);
						champion.setIcon(img);
				  Buttons.add(champion);
				  champion.setToolTipText(s);
				  champion.addActionListener(this);
				  Champ.add(champion);
				  Champ.revalidate();      Champ.repaint();
				
			  }
			 
			 
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}// end of first action
		
		if (e.getSource() == New) {
			if (Fname.getText().equals("")){ 
				JOptionPane.showMessageDialog (null, "You did not enter a name", "Please Enter a name", JOptionPane.WARNING_MESSAGE);
			}
			
			else {
				frame.dispose();
				DisChamp = new JFrame();
				DisChamp.setLayout(new BorderLayout());
				DisChamp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				DisChamp.setSize(1000,600);
				DisChamp.setVisible(true);
				DisChamp.setResizable(true);
				DisChamp.setBackground(new Color (0x123456));
				DisChamp.add(Champ , BorderLayout.CENTER);
				DisChamp.add(submit , BorderLayout.SOUTH);
				DisChamp.add(Team , BorderLayout.EAST);
				DisChamp.revalidate();  DisChamp.repaint();
			}
			
			if (Sname.getText().equals("")){
				JOptionPane.showMessageDialog (null, "You did not enter a name", "Please Enter a name", JOptionPane.WARNING_MESSAGE);
			}
			else {
			frame.dispose();
			DisChamp = new JFrame();
			DisChamp.setLayout(new BorderLayout());
			DisChamp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			DisChamp.setSize(1000,600);
			DisChamp.setVisible(true);
			DisChamp.setResizable(true);
			DisChamp.setBackground(new Color (0x123456));
			DisChamp.add(Champ , BorderLayout.CENTER);
			DisChamp.add(submit , BorderLayout.SOUTH);
			DisChamp.add(Team , BorderLayout.EAST);
			DisChamp.revalidate();  DisChamp.repaint();
			}

		}// end of second action
	
		for (int i = 0 ; i < Buttons.size() ; i ++) {
			if (e.getSource() == Buttons.get(i)) {
				
				if (firstPlayer.getTeam().size() < 3) {
					
					firstPlayer.getTeam().add(Game.getAvailableChampions().get(i));
					Buttons.get(i).setEnabled(false);
				}
			
				else
				
				if (secondPlayer.getTeam().size() < 3) {
					secondPlayer.getTeam().add(Game.getAvailableChampions().get(i));
					Buttons.get(i).setEnabled(false);
				
				}
			}
		}
		
		if (e.getSource() == submit) {
			
			if (firstPlayer.getTeam().size() < 3) {
				 JOptionPane.showMessageDialog (null, "First Player! Please choose your champions", "Title", JOptionPane.INFORMATION_MESSAGE);
			}
			else {
				
			if (secondPlayer.getTeam().isEmpty() && (!firstPlayer.getTeam().isEmpty()))	{
				JOptionPane.showMessageDialog (null, "Second Player! Please choose your champions", "Title", JOptionPane.INFORMATION_MESSAGE);
			}
				}
			left.add(new JLabel( Fname.getText()));
			for (int i = 0 ; i < firstPlayer.getTeam().size() ; i++) {
				JButton p1 = new JButton ();
				p1.setPreferredSize(new Dimension(150,30));
				p1.setText(firstPlayer.getTeam().get(i).getName());
				left.add(p1);
				left.repaint(); left.revalidate();
			}
			 left.add(new JLabel (Sname.getText()));
			for (int i = 0 ; i < secondPlayer.getTeam().size() ; i++) {
				JButton p2 = new JButton ();
				p2.setPreferredSize(new Dimension(150,30));
				p2.setText(secondPlayer.getTeam().get(i).getName());
				left.add(p2);
				left.repaint(); left.revalidate();
			}
			
		   
			DisChamp.dispose();
			FirstLeader = new JFrame();
			FirstLeader.setLayout(new BorderLayout());
			FirstLeader.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			FirstLeader.setSize(1000,600);
			FirstLeader.setVisible(true);
			FirstLeader.setResizable(true);
			FirstLeader.setBackground(new Color (0x123456));
			FirstLeader.add(Fleader,BorderLayout.WEST);
			FirstLeader.add(Sleader,BorderLayout.EAST);
			FirstLeader.add(FChoose,BorderLayout.SOUTH);
			
			for (int i = 0 ; i < firstPlayer.getTeam().size() ; i++) {
				FPleader = new JButton(firstPlayer.getTeam().get(i).getName());
				team1.add(FPleader);
				FPleader.addActionListener(this);
				Fleader.add(FPleader);
				Fleader.repaint();  Fleader.revalidate();
			}
			for (int i = 0 ; i < secondPlayer.getTeam().size() ; i++) {
				SPleader = new JButton(secondPlayer.getTeam().get(i).getName());
				team2.add(SPleader);
				SPleader.addActionListener(this);
				Sleader.add(SPleader);
				Sleader.repaint();  Sleader.revalidate();
			}
			FirstLeader.repaint(); FirstLeader.revalidate();
		}
			for (int i = 0 ; i < team1.size() ; i++) {
				if (e.getSource() == team1.get(i)) {
					team1.get(i).setEnabled(false);
					firstPlayer.setLeader(firstPlayer.getTeam().get(i));
					choseFirst();
				}
			}
			for (int i = 0 ; i < team2.size() ; i++) {
				if (e.getSource() == team2.get(i)) {
					secondPlayer.setLeader(secondPlayer.getTeam().get(i));
					choseSecond();
				}
			}
			
			if (e.getSource()== FChoose) {
				FirstLeader.dispose();
				Board = new JFrame();
				Board.setLayout(new BorderLayout());
				Board.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Board.setSize(1160,800);
				Board.setVisible(true);
				Board.setResizable(true);
				Board.setBackground(new Color (0x123456));
			    Board.add(DisBoard , BorderLayout.CENTER);
			    Board.add(right , BorderLayout.EAST);
			    Board.add(left , BorderLayout.WEST);
			    Board.add(up , BorderLayout.NORTH);
			    Board.add(down , BorderLayout.SOUTH);
			    down.add(moveUP, BorderLayout.EAST);
			    down.add(moveDOWN ,BorderLayout.EAST);
			    down.add(moveLEFT ,BorderLayout.EAST);
			    down.add(moveRIGHT, BorderLayout.EAST);
			    down.add(moveDOWN ,BorderLayout.EAST);
			    down.add(attackUP, BorderLayout.EAST);
			    down.add(attackDOWN, BorderLayout.EAST);
			    down.add(attackDOWN, BorderLayout.EAST);
			    down.add(attackLEFT, BorderLayout.EAST);
			    down.add(attackRIGHT, BorderLayout.EAST);
			    down.add(UseLeaderAbility,BorderLayout.EAST);
			    down.add(EndTurn , BorderLayout.EAST);

			    Board.repaint();   Board.revalidate();
			    
			    game = new Game(firstPlayer , secondPlayer); 
			    
			    Cast1.setText(game.getCurrentChampion().getAbilities().get(0).getName());
				right.add(Cast1);
				Cast2.setText(game.getCurrentChampion().getAbilities().get(1).getName());
				right.add(Cast2);
				Cast3.setText(game.getCurrentChampion().getAbilities().get(2).getName());
				right.add(Cast3);
				
//				try {
//					game.getCurrentChampion().getAbilities().get(3);
//					punch.setText("Punch");
//					right.add(punch);
//				}catch(NullPointerException h) {
//					
//				}
				
				
			    Object board[][]= game.getBoard();
			    
			     
			    for ( int i = Game.getBoardheight() -1 ; i >= 0 ; i--) {
			    	
			    	for ( int j = Game.getBoardwidth() -1 ; j >= 0  ; j-- ) {
			    		if ( board[i][j]==null) {
			    			JButton cell= new JButton("Empty");
			    			cell.setPreferredSize(new Dimension());
				    		DisBoard.add(cell);
				    		DisBoard.repaint(); DisBoard.revalidate();
			    		}
			    		else 
			    		
			    			if(board[i][j] instanceof Champion) {
			    				
				    			Champion x= (Champion) game.getBoard()[i][j];
				    			JButton cell= new JButton( x.getName()  + x.getCurrentHP());
					    		DisBoard.add(cell);
					    		DisBoard.repaint(); DisBoard.revalidate();
			    		}
			    			if (board[i][j] instanceof Cover ) {
			    			
			    			Cover x = (Cover) game.getBoard()[i][j];
			    			JButton cell= new JButton("Cover " + x.getCurrentHP());
				    		DisBoard.add(cell);
				    		DisBoard.repaint(); DisBoard.revalidate();
			    		}
			    		
			    	}
				}
			    DisBoard.repaint(); DisBoard.revalidate();
			    
			    PQ();

			    Champion currechamp = (Champion) game.getTurnOrder().peekMin();
			    			 s= "Current Champion Details: " + '\n' + "Name: "+ currechamp.getName() + '\n' + "Condition: " + currechamp.getCondition() +  '\n' + "Attack Damage: " +currechamp.getAttackDamage() + '\n'
					    	+"Attack Range: " + currechamp.getAttackRange()	+  '\n' +" Current Action Point:"+ currechamp.getCurrentActionPoints() +  '\n' + "Current HP: "+ 
					    	currechamp.getCurrentHP() +  '\n' + "Mana: " +currechamp.getMana() + '\n' + "Max Action Points Per Turn: " +currechamp.getMaxActionPointsPerTurn() +
					    	'\n' + "Maximum HP" +currechamp.getMaxHP() + '\n' + "Speed: " + currechamp.getSpeed() + '\n'+ 
					    	"Ability Name: "+ currechamp.getAbilities().get(0).getName() + '\n'+ "Base Cool Down: " + currechamp.getAbilities().get(0).getBaseCooldown() + '\n'+ "Cast Range: " +currechamp.getAbilities().get(0).getCastRange() + 
					    	'\n'+ "Current Cool Down: "	+ currechamp.getAbilities().get(0).getCurrentCooldown()+ '\n'+ "Mana Cost: "+ currechamp.getAbilities().get(0).getManaCost() + '\n'+
					    	"Required Action Points: "+ currechamp.getAbilities().get(0).getRequiredActionPoints() +'\n';
					    	if (currechamp.getAbilities().get(0) instanceof DamagingAbility) {
					    		s+= "Ability Type: Damaging Ability" +'\n'; 
					    		DamagingAbility a= (DamagingAbility) currechamp.getAbilities().get(0);
					    		s+="Damaging Amount: " + a.getDamageAmount();
					    	}
					    	if (currechamp.getAbilities().get(0) instanceof HealingAbility) {
					    		s+= "Ability Type: Healing Ability"+'\n';
					    		HealingAbility a= (HealingAbility) currechamp.getAbilities().get(0);
					    		s+="Damaging Amount: " + a.getHealAmount();
					    	}
					    	if (currechamp.getAbilities().get(0) instanceof CrowdControlAbility) {
					    		s+= "Ability Type: Crowd Control Ability"+'\n';
					    		CrowdControlAbility a= (CrowdControlAbility) currechamp.getAbilities().get(0);
					    		s+="Effect: " + a.getEffect().getName();
					    	}
					    	
					    	s+= '\n'+"Ability Name: "+currechamp.getAbilities().get(1).getName()+
					    	 '\n'+ "Base Cool Down: " + currechamp.getAbilities().get(1).getBaseCooldown() + '\n'+ "Cast Range: " +currechamp.getAbilities().get(1).getCastRange() + 
					    	'\n'+ "Current Cool Down: "	+ currechamp.getAbilities().get(1).getCurrentCooldown()+ '\n'+ "Mana Cost: "+ currechamp.getAbilities().get(1).getManaCost() + '\n'+
					    	"Required Action Points: "+ currechamp.getAbilities().get(1).getRequiredActionPoints()+ '\n';
					    	
					    	if (currechamp.getAbilities().get(1) instanceof DamagingAbility) {
					    		s+= "Ability Type: Damaging Ability" +'\n'; 
					    		DamagingAbility a= (DamagingAbility) currechamp.getAbilities().get(1);
					    		s+="Damaging Amount: " + a.getDamageAmount();
					    	}
					    	if (currechamp.getAbilities().get(1) instanceof HealingAbility) {
					    		s+= "Ability Type: Healing Ability"+'\n';
					    		HealingAbility a= (HealingAbility) currechamp.getAbilities().get(1);
					    		s+="Heal Amount: " + a.getHealAmount();
					    	
					    	}
					    	if (currechamp.getAbilities().get(1) instanceof CrowdControlAbility) {
					    		s+= "Ability Type: Crowd Control Ability"+'\n';
					    		CrowdControlAbility a= (CrowdControlAbility) currechamp.getAbilities().get(1);
					    		s+="Effect: " + a.getEffect().getName();
					    	}
					    	s+= '\n'+"Ability Name: "+currechamp.getAbilities().get(2).getName()+ '\n'+ "Base Cool Down: " + currechamp.getAbilities().get(2).getBaseCooldown() + '\n'+ "Cast Range: " +currechamp.getAbilities().get(2).getCastRange() + 
							    	'\n'+ "Current Cool Down: "	+ currechamp.getAbilities().get(2).getCurrentCooldown()+ '\n'+ "Mana Cost: "+ currechamp.getAbilities().get(2).getManaCost() + '\n'+
							    	"Required Action Points: "+ currechamp.getAbilities().get(2).getRequiredActionPoints() + '\n';
					    	
					    	if (currechamp.getAbilities().get(2) instanceof DamagingAbility) {
					    		s+= "Ability Type: Damaging Ability" +'\n'; 
					    		DamagingAbility a= (DamagingAbility) currechamp.getAbilities().get(2);
					    		s+="Damaging Amount: " + a.getDamageAmount();
					    	}
					    	if (currechamp.getAbilities().get(2) instanceof HealingAbility) {
					    		s+= "Ability Type: Healing Ability"+'\n';
					    		HealingAbility a= (HealingAbility) currechamp.getAbilities().get(2);
					    		s+="Heal Amount: " + a.getHealAmount();
					    	}
					    	if (currechamp.getAbilities().get(2) instanceof CrowdControlAbility) {
					    		s+= "Ability Type: Crowd Control Ability"+'\n';
					    		CrowdControlAbility a= (CrowdControlAbility) currechamp.getAbilities().get(1);
					    		s+="Effect: " + a.getEffect().getName();
					    	}
					    for (int i=0;i<currechamp.getAppliedEffects().size();i++) {
					    	s+="Effect:"+ currechamp.getAppliedEffects().get(i).getName() + currechamp.getAppliedEffects().get(i).getDuration() + currechamp.getAppliedEffects().get(i).getType() +'\n' ;
					   
					    }
					    
					    Curr.setText (s);
					    right.revalidate(); right.repaint();
			   
			}// end of button
			 
			if (e.getSource() == moveUP) {
				try {
					
					game.move(Direction.UP);
					System.out.println("HABIBA");
					boardRefresh();
					curr();
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
				} catch (UnallowedMovementException e1) {
					JOptionPane.showMessageDialog (null, "you Can not move to the needed place", "Alert", JOptionPane.INFORMATION_MESSAGE);
				}
				
			} // end of up move
			
			if (e.getSource() == moveDOWN) {
				try {
					game.move(Direction.DOWN);
					boardRefresh();
					curr();
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
				} catch (UnallowedMovementException e1) {
					JOptionPane.showMessageDialog (null, "you Can not move to the needed place", "Alert", JOptionPane.INFORMATION_MESSAGE);
				}
				
			} // end of down move
			if (e.getSource()==moveRIGHT) {
				try {
					game.move(Direction.LEFT);
					boardRefresh();
					curr();
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
				} catch (UnallowedMovementException e1) {
					JOptionPane.showMessageDialog (null, "you Can not move to the needed place", "Alert", JOptionPane.INFORMATION_MESSAGE);
				}
				
			} //end of right move
			if (e.getSource() == moveLEFT) {
				try {
					game.move(Direction.RIGHT);
					boardRefresh();
					curr();
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
				} catch (UnallowedMovementException e1) {
					JOptionPane.showMessageDialog (null, "you Can not move to the needed place", "Alert", JOptionPane.INFORMATION_MESSAGE);
				}
			} //end of left move
			
				if (e.getSource() == attackDOWN) {
					try {
						game.attack(Direction.DOWN);
						boardRefresh();
						curr();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (ChampionDisarmedException e1) {
						JOptionPane.showMessageDialog (null, "Your Champion is Disarmed", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (InvalidTargetException e1) {
						JOptionPane.showMessageDialog (null, "You cannot attack champion from your team", "Alert", JOptionPane.INFORMATION_MESSAGE);
					}
				}
				if (e.getSource() == attackUP) {
					try {
						game.attack(Direction.UP);
						boardRefresh();
						curr();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (ChampionDisarmedException e1) {
						JOptionPane.showMessageDialog (null, "Your Champion is Disarmed", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (InvalidTargetException e1) {
						JOptionPane.showMessageDialog (null, "You cannot attack champion from your team", "Alert", JOptionPane.INFORMATION_MESSAGE);
					}
				}
			if (e.getSource() == attackRIGHT) {
				
					
					try {
						game.attack(Direction.LEFT);
						boardRefresh();
						curr();
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (ChampionDisarmedException e1) {
						JOptionPane.showMessageDialog (null, "Your Champion is Disarmed", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (InvalidTargetException e1) {
						JOptionPane.showMessageDialog (null, "You cannot attack champion from your team", "Alert", JOptionPane.INFORMATION_MESSAGE);
					}
					boardRefresh();
				
			}
			if (e.getSource() == attackLEFT) {
				try {
					game.attack(Direction.RIGHT);
					boardRefresh();
					curr();
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					
				} catch (ChampionDisarmedException e1) {
					JOptionPane.showMessageDialog (null, "Your Champion is Disarmed", "Alert", JOptionPane.INFORMATION_MESSAGE);
						
				} catch (InvalidTargetException e1) {
					JOptionPane.showMessageDialog (null, "You cannot attack champion from your team", "Alert", JOptionPane.INFORMATION_MESSAGE);
					
				}
			}
			
			if (e.getSource() == UseLeaderAbility) {
		
				try {
					game.useLeaderAbility();
				} catch (LeaderNotCurrentException e1) {
					JOptionPane.showMessageDialog (null, "it is not your leader's order", "Alert", JOptionPane.INFORMATION_MESSAGE);
				} catch (LeaderAbilityAlreadyUsedException e1) {
					JOptionPane.showMessageDialog (null, "Your Leader has used his ability before", "Alert", JOptionPane.INFORMATION_MESSAGE);
				}
				boardRefresh();
			}
		
			if (e.getSource() == EndTurn) {
				 game.endTurn();
				 UpdatePQ();
				 Board.add(up);
				 curr();
				 Board.revalidate();  Board.repaint();
			}
if (e.getSource()==CastAbility) {
				
				ability = new JFrame ("Chose Ability");
				ability.setLayout(new GridLayout(0,3));
				ability.setVisible(true);
				ability.setSize(500,300);
				ability.add(Cast1);
				ability.add(Cast2);
				ability.add(Cast3);
				ability.repaint(); ability.revalidate();
			}
			if (e.getSource() == Cast1) {
				
				if ((game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SELFTARGET )|| 
					(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.TEAMTARGET) || 
					(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SURROUND)) {
					try {
						game.castAbility(game.getCurrentChampion().getAbilities().get(0));
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog (null, "You can not cast this ability", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						
					}
				}
				else if (game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.DIRECTIONAL) {
						String y= (JOptionPane.showInputDialog("Enter Direction: "));
					
					try {
						game.castAbility(game.getCurrentChampion().getAbilities().get(1),Direction.valueOf(y));
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog (null, "You can not cast this ability", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						
					}
				}
				else {
					String x= (JOptionPane.showInputDialog("Enter x: "));
					String y= (JOptionPane.showInputDialog("Enter y: "));
				try {
					game.castAbility(game.getCurrentChampion().getAbilities().get(1),Integer.parseInt(y),Integer.parseInt(x));
					}  catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog (null, "You can not cast this ability", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (InvalidTargetException e1) {
						JOptionPane.showMessageDialog (null, "You cannot attack champion from your team", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						
					}
				}
			}
		
		if (e.getSource() == Cast2) {
			if ((game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SELFTARGET )|| 
					(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.TEAMTARGET) || 
					(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SURROUND)) {
					try {
						game.castAbility(game.getCurrentChampion().getAbilities().get(1));
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog (null, "You can not cast this ability", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						
					}
				}
				else if (game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.DIRECTIONAL) {
					String y= (JOptionPane.showInputDialog("Enter Direction: "));
					
					try {
						game.castAbility(game.getCurrentChampion().getAbilities().get(1),Direction.valueOf(y));
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog (null, "You can not cast this ability", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						
					}
				}
				else {
					String x= (JOptionPane.showInputDialog("Enter x: "));
					String y= (JOptionPane.showInputDialog("Enter y: "));
					
					
					try {
						game.castAbility(game.getCurrentChampion().getAbilities().get(1),Integer.parseInt(y),Integer.parseInt(x));
					}  catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog (null, "You can not cast this ability", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (InvalidTargetException e1) {
						JOptionPane.showMessageDialog (null, "You cannot attack champion from your team", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						
					}
				}
		}
		if (e.getSource() == Cast3) {
			if ((game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SELFTARGET )|| 
					(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.TEAMTARGET) || 
					(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SURROUND)) {
					try {
						game.castAbility(game.getCurrentChampion().getAbilities().get(2));
					} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog (null, "You can not cast this ability", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						
					}
				}
				else if (game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.DIRECTIONAL) {
					String y= (JOptionPane.showInputDialog("Enter Direction: "));
					try {
						game.castAbility(game.getCurrentChampion().getAbilities().get(1),Direction.valueOf(y));				
						} catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog (null, "You can not cast this ability", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						
					}
				}
				else {
					String x= (JOptionPane.showInputDialog("Enter x: "));
					String y= (JOptionPane.showInputDialog("Enter y: "));
					try {
						game.castAbility(game.getCurrentChampion().getAbilities().get(1),Integer.parseInt(y),Integer.parseInt(x));
					}  catch (NotEnoughResourcesException e1) {
						JOptionPane.showMessageDialog (null, "You do not have enough resources", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (AbilityUseException e1) {
						JOptionPane.showMessageDialog (null, "You can not cast this ability", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (InvalidTargetException e1) {
						JOptionPane.showMessageDialog (null, "You cannot attack champion from your team", "Alert", JOptionPane.INFORMATION_MESSAGE);
					} catch (CloneNotSupportedException e1) {
						
					}
				}
		}
	
			
	}// end of actionPerformed
	
	public void PQ () {
		
		while(!(game.getTurnOrder().isEmpty())) {
			
			Champion x = (Champion) game.getTurnOrder().peekMin();
			temp.add(x);
			game.getTurnOrder().remove();
			
		}
		for (int i = 0; i < temp.size() ; i++) {
			
			Champion y = (Champion) temp.get(i);
			game.getTurnOrder().insert(y);
		}
		
		 for (int i = 0 ;i < temp.size() ; i++) {
		    	JButton x= new JButton (temp.get(i).getName());
		    	x.setBounds(350,450,300,40);
		    	x.repaint(); x.revalidate();
		    	up.add(x);
		    	up.repaint(); up.revalidate();
		    	Board.add(up);
		    }
		 Champion currechamp=(Champion) game.getTurnOrder().peekMin();
			
		 s= "Current Champion Details: " + '\n' + "Name: "+ currechamp.getName() + '\n' + "Condition: " + currechamp.getCondition() +  '\n' + "Attack Damage: " +currechamp.getAttackDamage() + '\n'
			    	+"Attack Range: " + currechamp.getAttackRange()	+  '\n' +" Current Action Point:"+ currechamp.getCurrentActionPoints() +  '\n' + "Current HP: "+ 
			    	currechamp.getCurrentHP() +  '\n' + "Mana: " +currechamp.getMana() + '\n' + "Max Action Points Per Turn: " +currechamp.getMaxActionPointsPerTurn() +
			    	'\n' + "Maximum HP" +currechamp.getMaxHP() + '\n' + "Speed: " + currechamp.getSpeed() + '\n'+ 
			    	"Ability Name: "+ currechamp.getAbilities().get(0).getName() + '\n'+ "Base Cool Down: " + currechamp.getAbilities().get(0).getBaseCooldown() + '\n'+ "Cast Range: " +currechamp.getAbilities().get(0).getCastRange() + 
			    	'\n'+ "Current Cool Down: "	+ currechamp.getAbilities().get(0).getCurrentCooldown()+ '\n'+ "Mana Cost: "+ currechamp.getAbilities().get(0).getManaCost() + '\n'+
			    	"Required Action Points: "+ currechamp.getAbilities().get(0).getRequiredActionPoints() +'\n';
			    	if (currechamp.getAbilities().get(0) instanceof DamagingAbility) {
			    		s+= "Ability Type: Damaging Ability" +'\n'; 
			    		DamagingAbility a= (DamagingAbility) currechamp.getAbilities().get(0);
			    		s+="Damaging Amount: " + a.getDamageAmount();
			    	}
			    	if (currechamp.getAbilities().get(0) instanceof HealingAbility) {
			    		s+= "Ability Type: Healing Ability"+'\n';
			    		HealingAbility a= (HealingAbility) currechamp.getAbilities().get(0);
			    		s+="Damaging Amount: " + a.getHealAmount();
			    	}
			    	if (currechamp.getAbilities().get(0) instanceof CrowdControlAbility) {
			    		s+= "Ability Type: Crowd Control Ability"+'\n';
			    		CrowdControlAbility a= (CrowdControlAbility) currechamp.getAbilities().get(0);
			    		s+="Effect: " + a.getEffect().getName();
			    	}
			    	
			    	s+= '\n'+"Ability Name: "+currechamp.getAbilities().get(1).getName()+
			    	 '\n'+ "Base Cool Down: " + currechamp.getAbilities().get(1).getBaseCooldown() + '\n'+ "Cast Range: " +currechamp.getAbilities().get(1).getCastRange() + 
			    	'\n'+ "Current Cool Down: "	+ currechamp.getAbilities().get(1).getCurrentCooldown()+ '\n'+ "Mana Cost: "+ currechamp.getAbilities().get(1).getManaCost() + '\n'+
			    	"Required Action Points: "+ currechamp.getAbilities().get(1).getRequiredActionPoints()+ '\n';
			    	
			    	if (currechamp.getAbilities().get(1) instanceof DamagingAbility) {
			    		s+= "Ability Type: Damaging Ability" +'\n'; 
			    		DamagingAbility a= (DamagingAbility) currechamp.getAbilities().get(1);
			    		s+="Damaging Amount: " + a.getDamageAmount();
			    	}
			    	if (currechamp.getAbilities().get(1) instanceof HealingAbility) {
			    		s+= "Ability Type: Healing Ability"+'\n';
			    		HealingAbility a= (HealingAbility) currechamp.getAbilities().get(1);
			    		s+="Heal Amount: " + a.getHealAmount();
			    	
			    	}
			    	if (currechamp.getAbilities().get(1) instanceof CrowdControlAbility) {
			    		s+= "Ability Type: Crowd Control Ability"+'\n';
			    		CrowdControlAbility a= (CrowdControlAbility) currechamp.getAbilities().get(1);
			    		s+="Effect: " + a.getEffect().getName();
			    	}
			    	s+= '\n'+"Ability Name: "+currechamp.getAbilities().get(2).getName()+ '\n'+ "Base Cool Down: " + currechamp.getAbilities().get(2).getBaseCooldown() + '\n'+ "Cast Range: " +currechamp.getAbilities().get(2).getCastRange() + 
					    	'\n'+ "Current Cool Down: "	+ currechamp.getAbilities().get(2).getCurrentCooldown()+ '\n'+ "Mana Cost: "+ currechamp.getAbilities().get(2).getManaCost() + '\n'+
					    	"Required Action Points: "+ currechamp.getAbilities().get(2).getRequiredActionPoints() + '\n';
			    	
			    	if (currechamp.getAbilities().get(2) instanceof DamagingAbility) {
			    		s+= "Ability Type: Damaging Ability" +'\n'; 
			    		DamagingAbility a= (DamagingAbility) currechamp.getAbilities().get(2);
			    		s+="Damaging Amount: " + a.getDamageAmount();
			    	}
			    	if (currechamp.getAbilities().get(2) instanceof HealingAbility) {
			    		s+= "Ability Type: Healing Ability"+'\n';
			    		HealingAbility a= (HealingAbility) currechamp.getAbilities().get(2);
			    		s+="Heal Amount: " + a.getHealAmount();
			    	}
			    	if (currechamp.getAbilities().get(2) instanceof CrowdControlAbility) {
			    		s+= "Ability Type: Crowd Control Ability"+'\n';
			    		CrowdControlAbility a= (CrowdControlAbility) currechamp.getAbilities().get(1);
			    		s+="Effect: " + a.getEffect().getName();
			    	}
			    for (int i=0;i<currechamp.getAppliedEffects().size();i++) {
			    	s+="Effect:"+ currechamp.getAppliedEffects().get(i).getName() + currechamp.getAppliedEffects().get(i).getDuration() + currechamp.getAppliedEffects().get(i).getType() +'\n' ;
			   
			    }
			    
			    Curr.setText (s);
			    right.revalidate(); right.repaint();
		
	}
	public void boardRefresh() {
		
		Object board[][]= game.getBoard();
	    DisBoard.removeAll();
	    DisBoard.repaint();  DisBoard.revalidate();
	    for ( int i =  Game.getBoardheight()-1 ; i >= 0 ; i--) {
	    	
	    	for ( int j = Game.getBoardwidth() -1 ; j >= 0  ; j-- ) {
	    		if ( board[i][j] == null) {
	    			JButton cell= new JButton("Empty");
		    		DisBoard.add(cell);
		    		
	    		}
	    		else if(board[i][j] instanceof Champion) {
		    			Champion x = (Champion) game.getBoard()[i][j];
		    			JButton cell= new JButton( x.getName()  + x.getCurrentHP());
			    		DisBoard.add(cell);
	    		}
	    		if (board[i][j] instanceof Cover ) {
	    			Cover x= (Cover) game.getBoard()[i][j];
	    			JButton cell= new JButton("Cover " + x.getCurrentHP());
		    		DisBoard.add(cell);
		  
	    		}
	    		
	    	}
	    	DisBoard.repaint(); DisBoard.revalidate();
		} 
	    Board.add(up , BorderLayout.NORTH);
	    Board.add(DisBoard , BorderLayout.CENTER);
	    Board.add(down , BorderLayout.SOUTH);
	   
	    Board.repaint(); Board.revalidate();
		
	}
	public void UpdatePQ() {
		up.removeAll();
		ArrayList<Champion> tmp = new ArrayList<>();
			while(!(game.getTurnOrder().isEmpty())) {
				
				Champion x = (Champion) game.getTurnOrder().peekMin();
				tmp.add(x);
				game.getTurnOrder().remove();
				
			}
			for (int i = 0 ;i < tmp.size() ; i++) {
			
				game.getTurnOrder().insert(tmp.get(i));
	
			}
			 for (int i = 0 ;i < tmp.size() ; i++) {
			    	JButton x= new JButton (tmp.get(i).getName());
			    	x.setBounds(350,450,300,40);
			    	x.repaint(); x.revalidate();
			    	up.add(x);
			    	up.repaint(); up.revalidate();
			    	Board.add(up);
			    }
			 
			    Cast1.setText(game.getCurrentChampion().getAbilities().get(0).getName()+'\n');
				ability.add(Cast1);
				Cast2.setText(game.getCurrentChampion().getAbilities().get(1).getName()+'\n');
				ability.add(Cast2);
				Cast3.setText(game.getCurrentChampion().getAbilities().get(2).getName()+'\n');
				ability.add(Cast3);
				up.repaint(); up.revalidate();
		    	
		    	DisBoard.repaint(); DisBoard.revalidate();
	}
	
	
	public void choseFirst(){
		for(JButton b:team1)
			b.setEnabled(false);
	}
	
	public void choseSecond(){
		for(JButton b:team2)
			b.setEnabled(false);
	}
	public void curr() {
		 Champion currechamp=(Champion) game.getTurnOrder().peekMin();
		 s= "Name: "+ currechamp.getName() + '\n' + "Condition: " + currechamp.getCondition() +  '\n' + "Attack Damage: " +currechamp.getAttackDamage() + '\n'
			    	+"Attack Range: " + currechamp.getAttackRange()	+  '\n' +" Current Action Point:"+ currechamp.getCurrentActionPoints() +  '\n' + "Current HP: "+ 
			    	currechamp.getCurrentHP() +  '\n' + "Mana: " +currechamp.getMana() + '\n' + "Max Action Points Per Turn: " +currechamp.getMaxActionPointsPerTurn() +
			    	'\n' + "Maximum HP" +currechamp.getMaxHP() + '\n' + "Speed: " + currechamp.getSpeed() + '\n'+ 
			    	"Ability Name: "+ currechamp.getAbilities().get(0).getName() + '\n'+ "Base Cool Down: " + currechamp.getAbilities().get(0).getBaseCooldown() + '\n'+ "Cast Range: " +currechamp.getAbilities().get(0).getCastRange() + 
			    	'\n'+ "Current Cool Down: "	+ currechamp.getAbilities().get(0).getCurrentCooldown()+ '\n'+ "Mana Cost: "+ currechamp.getAbilities().get(0).getManaCost() + '\n'+
			    	"Required Action Points: "+ currechamp.getAbilities().get(0).getRequiredActionPoints() +'\n';
			    	if (currechamp.getAbilities().get(0) instanceof DamagingAbility) {
			    		s+= "Ability Type: Damaging Ability"; 
			    	}
			    	if (currechamp.getAbilities().get(0) instanceof HealingAbility) {
			    		s+= "Ability Type: Healing Ability";
			    		Ability H= currechamp.getAbilities().get(0);
			    	
			    	}
			    	if (currechamp.getAbilities().get(0) instanceof CrowdControlAbility) {
			    		s+= "Ability Type: Crowd Control Ability";
			    	}
			    	
			    	s+= '\n'+"Ability Name: "+currechamp.getAbilities().get(1).getName()+
			    	 '\n'+ "Base Cool Down: " + currechamp.getAbilities().get(1).getBaseCooldown() + '\n'+ "Cast Range: " +currechamp.getAbilities().get(1).getCastRange() + 
			    	'\n'+ "Current Cool Down: "	+ currechamp.getAbilities().get(1).getCurrentCooldown()+ '\n'+ "Mana Cost: "+ currechamp.getAbilities().get(1).getManaCost() + '\n'+
			    	"Required Action Points: "+ currechamp.getAbilities().get(1).getRequiredActionPoints()+ '\n';
			    	if (currechamp.getAbilities().get(1) instanceof DamagingAbility) {
			    		s+= "Ability Type: Damaging Ability"; 
			    	}
			    	if (currechamp.getAbilities().get(1) instanceof HealingAbility) {
			    		s+= "Ability Type: Healing Ability";
			    		Ability H= currechamp.getAbilities().get(1);
			    	
			    	}
			    	if (currechamp.getAbilities().get(1) instanceof CrowdControlAbility) {
			    		s+= "Ability Type: Crowd Control Ability";
			    	}
			    	s+= '\n'+ "Ability Name: "+currechamp.getAbilities().get(2).getName()+ '\n'+ "Base Cool Down: " + currechamp.getAbilities().get(2).getBaseCooldown() + '\n'+ "Cast Range: " +currechamp.getAbilities().get(2).getCastRange() + 
					    	'\n'+ "Current Cool Down: "	+ currechamp.getAbilities().get(2).getCurrentCooldown()+ '\n'+ "Mana Cost: "+ currechamp.getAbilities().get(2).getManaCost() + '\n'+
					    	"Required Action Points: "+ currechamp.getAbilities().get(2).getRequiredActionPoints() + '\n';
			    	if (currechamp.getAbilities().get(2) instanceof DamagingAbility) {
			    		s+= "Ability Type: Damaging Ability"; 
			    	}
			    	if (currechamp.getAbilities().get(2) instanceof HealingAbility) {
			    		s+= "Ability Type: Healing Ability";
			    		Ability H= currechamp.getAbilities().get(2);
			    
			    	}
			    	if (currechamp.getAbilities().get(2) instanceof CrowdControlAbility) {
			    		s+= "Ability Type: Crowd Control Ability";
			    	}
			    for (int i=0;i<currechamp.getAppliedEffects().size();i++) {
			    	s+=  "Effects: "+ currechamp.getAppliedEffects().get(i).getName() + currechamp.getAppliedEffects().get(i).getDuration() + currechamp.getAppliedEffects().get(i).getType() ;
			   
			    }
			    
			    Curr.setText (s);
			    right.revalidate(); right.repaint();
	}
	
	public static void main( String [] args) {
		new GameGUI();
	}
	
	
	
}

